---
layout: index

title: José Domingo Muñoz	
tagline: josedom24.github.io
---
![yo](/img/yo1.jpg)

## Bienvenid@s

* [Ejercicios y prácticas de módulos de ASIR y SMR](/mod)
<hr/>
* [Tutoriales, cursos,...](/varios/tutorial)
<hr/>
* [Internet, web, ...](/varios/web)
<hr/>
* [Enlaces, páginas completas interesantes...](/varios/enlaces)
<hr/>
* [Cajón desastre...](varios/cajon)
<hr/>
* [Colección de libros libres](/libros)
