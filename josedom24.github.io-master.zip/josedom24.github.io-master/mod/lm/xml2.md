---
layout: index

title: Lenguaje de marcas
tagline: CFGS ASIR
---

### Ejercicio 2 xml: Modificar ficheros XML

Ejercicio 1: Modifica el fichero book.xml, de la siguiente forma:

* Abre el fichero book.xml y modifica el año del segundo libro.
* Cambia el atributo del elemento book del primer elemento.
* Añade un nuevo libro.
* Cuando finalice, copia el resultado en un fichero llamdo book2.xml

Ejercicio 2: crea sel siguiente documento XML y guardalo en el fichero licencias.xml:

	<?xml version="1.0" encoding="UTF-8"?>
	<licencias>
		<licencia>
			<nombre>Creative Commons By - Share Alike</nombre>
			<imagen>cc_bysa_88x31.png</imagen>
		</licencia>
	</licencias>

[Volver](index)
