---
layout: index

title: Ejercicios y prácticas de módulos de ASIR y SMR
tagline: 
---

## Ejercicios y prácticas de módulos de ASIR y SMR

#### ASIR

* [Lenguajes de marcas](/mod/lm)
* [Implantación de aplicaciones web](/mod/iaw)
* [Servicios en red e internet](/mod/serviciosgs)
* [Servicios en red e internet 2015-2016](/mod/serviciosgs/2015-2016)

#### SMR

* [Servicios en red](/mod/serviciosgm)
* [Aplicaciones Webs](/mod/aplweb)

<hr/>



