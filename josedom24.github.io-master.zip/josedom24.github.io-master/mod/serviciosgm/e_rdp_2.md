---
layout: index

title: Servicios de red 
tagline: CFGM SMR
---
### Ejercicio: Acceso al escritorio remoto del servidor de tu casa

Usando el nombre de dominio que reservamos en dyndns, configura el servidor Windows 2008 de tu casa, configura el router para direccionar el puerto oportuno y muestra al profesor un acceso remoto conectando a tunombrededominio.dyndns.com.

[Volver](index)
