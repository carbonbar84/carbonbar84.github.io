Ejercicio: Instalación y configuración de un servidor FTP anónimo
=================================================================

1. Configura el servidor FTP para que permita el acceso anónimo de sólo lectura (siendo el directorio particular ``c:/inetpub/ftp/public``, añade a ese directorio varios ficheros para comprobar que funciona).

Recuerda la configuración:

	* Configuración SSL de FTP: Permitir conexiones SSL
	* NO aislar usuarios. Directorio raíz de FTP (por defecto)

2. Configura el servidor DNS para poder acceder al servidor ``ftp.iesgn.com``

3. Accede desde los dos clientes a ``ftp.iesgn.com`` de forma anónima.


