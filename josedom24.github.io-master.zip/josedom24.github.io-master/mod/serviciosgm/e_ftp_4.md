---
layout: index

title: Servicios de red 
tagline: CFGM SMR
---
### Ejercicio: Acceso a un servidor FTP desde Intenet

Usando el nombre de dominio que reservamos en dyndns, configura un sitio FTP en el ordenador de tu casa, configura el router para direccionar los puertos oportunos y muestra al profesor un acceso autentificado al servidor FTP desde el aula, conectando a ftp://tunombrededominio.dyndns.com.

[Volver](index)
