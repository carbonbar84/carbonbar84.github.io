---
layout: index

title: Servicios de red 
tagline: CFGM SMR
---
### Ejercicio: Estudio de programas de acceso remoto en modo gráfico

Realizarán una presentacion, donde como mínimo aparezcan estos puntos:

1. Introducción breve explicando el software
2. Pasos para su instalación
3. Configuración del servidor y los clientes
4. Sistemas operativos que se pueden utilzar tanto para el servidor como para el cliente.
5. Explicación de como acceder a un servidor desde internet, estudio del puerto que utiliza,...


[Volver](index)
