---
layout: index

title: Servicios de red 
tagline: CFGM SMR
---
### Ejercicio: Gestión remota usando VNC

Para permitir el acceso remoto a nuestro escritorio, habilitamos la opción en:

**Sistema-> Preferencias-> Escritorio remoto**

Se pueden poner varias opciones: por ejemplo que haya que pedir confirmación en cada conexión o sea necesario escribir una contraseña.



<div class='ejercicios' markdown='1'>
##### **Ejercicios**

Configura el acceso remoto en el cliente ubuntu, para ver el escritorio remoto necesito un cliente, entrega capturas de pantalla donde se vea:

* Un cliente linux accediendo con el cliente vncviewer
* Un cliente linux accediendo desde el "Cliente de escritorio remoto Remmina".
* Un cliente Windows accediendo desde un cliente vnc (busca uno)

</div>


[Volver](index)
