---
layout: index

title: Servicios de red
tagline: CFGM SMR
---
### Ejercicio: Configuración de correo en servidor externo

Queremos configurar una cuenta de correos en nuestro hosting de hostinger, para ello vamos a realizar los siguientes puntos:

1. Crea una cuenta de correos, en la opción: **Cuentas de correo**, puedes modificar el tamaño del buzón hasta los 50Gb.
2. Prueba a mandar y recibir correos desde los Webmail que te ofrece la plataforma (opeción **Webmail**) tienes dos opciones: Round Cube y SquirreMail. Si quieres acceder al webmail sin tener que estar logueado a hostinger, prueba a acceder a http://webmail.hostinger.es
3. Comprueba los datos de correos del servidor (**Cuentas**->**Detalles**->**Detalles de E-mail**) y configura un clinete de correos para recibir y mandar correos con tu nueva dirección.


[Volver](index)

