---
layout: index

title: Servicios de red 
tagline: CFGM SMR
---
### Ejercicio: Escritorio remoto en Windows 2008 Server

Siguiendo los pasos del [manual](http://dit.gonzalonazareno.org/moodle/mod/resource/view.php?id=858) que puedes encontrar en la página, accede dede los clientes al servidor Windows 2008 usando el escritorio remoto.

<div class='ejercicios' markdown='1'>
##### **Ejercicios**
1. Accede desde un cliente linux y otro windows al servidor homer.iesgn.org con el protocolo RDP.
2. Crea otro usuario en Windows 2008, concédele permiso para acceder de forma remota, y accede a hommer.iesgn.com  con el usuario que acabas de crear. 

</div>
[Volver](index)
