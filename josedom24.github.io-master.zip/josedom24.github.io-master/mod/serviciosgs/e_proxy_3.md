---
layout: index

title: Servicios de Red e Internet
tagline: CFGS ASIR
---
### Ejercicio: Forzar el contenido cacheado


Configura squid para cachear el doodle (imagen con el logo de google) durante 365 días, de manera que se sirva siempre el mismo logo independientemente de que cambie en el sitio original.

[Volver](index)
