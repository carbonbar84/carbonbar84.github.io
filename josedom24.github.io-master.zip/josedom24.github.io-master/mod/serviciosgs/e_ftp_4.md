---
layout: index

title: Servicios de Red e Internet
tagline: CFGS ASIR
---
### Ejercicio: Instalación de net2ftp

Siguiendo las instrucciones de la página principal de net2ftp instala en tu servidor dicha aplicación. Crea un virtual hosting para que podamos acceder a dicha página con webftp.iesgn.com. Modifica adecuadamente el servidor DNS.

[Volver](index)
