---
layout: index

title: Servicios de Red e Internet
tagline: CFGS ASIR
---
### Ejercicio: Módulos en Apache

En este ejercicio debes activar los módulos info y status que dan información acerca del servidor web y comprobar su funcionamiento.

* El módulo [info](http://httpd.apache.org/docs/2.2/mod/mod_info.html) nos da información de la configuración con que se está ejecutando el servidor, indicando los distintos módulos, estáticos y dinámicos, que se encuentran cargados, así como las directivas de los mismos que están siendo usadas.
* El módulo [status](http://httpd.apache.org/docs/2.2/mod/mod_status.html)  muestra el estado en que se encuentra el servidor.

[Volver](index)
