---
layout: index

title: Servicios de Red e Internet
tagline: CFGS ASIR
---
### Ejercicio: Autenticación básica por usuarios y grupos con Squid

Configura squid para controlar el acceso de distintos tipos de usuarios:

* Los usarios del perfil "alumnos" solo pueden navegar a páginas cuya URL contenga gonzalonazareno.
* Los usarios del perfil "profesores" admeás pueden navegar por paǵinas que contengan la palabra "juntadeandalucia".
* Los usarios del perfil "equipo directivo" pueden navegar por cualquier página.


[Volver](index)
