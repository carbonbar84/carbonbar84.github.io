---
layout: index

title: Servicios de Red e Internet
tagline: CFGS ASIR
---
### Ejercicio: Directorios web para cada usuario (public_html)

El módulo [userdir](http://httpd.apache.org/docs/2.2/mod/mod_userdir.html) permite que cada usuario del sistema tenga la posibilidad de tener un directorio (por defecto se llama public_html) donde alojar su página web.

1. Activa el módulo y comprueba su funcionamiento.
2. Comprueba las opciones configuradas para los directorios public_html.
3. Cambia el nombre de directorio public_html por otro nombre.
4. Publica una página de un usuario, y accede a la misma.

[Volver](index)
