---
layout: index

title: Servicios de Red e Internet
tagline: CFGS ASIR
---
### Ejercicio: Autentificación con MySql

Utilizando el módulo **libapache2-mod-auth-mysql** y siguiendo algún tutorial que busques en internet, por ejemplo [este](http://blog.unlugarenelmundo.es/2010/03/18/autenticacion-en-apache-y-ii-digest-y-con-mysql/), configura un sitio virtual cuyo acceso sea autentificado mediante usuarios guardados en un tabla MySql. Nota: las contraseñas de los usuarios se deben guardar encriptadas.

**Nota:** No instales *phpmyadmin* para gestionar la base de datos que necesitas.

[Volver](index)
