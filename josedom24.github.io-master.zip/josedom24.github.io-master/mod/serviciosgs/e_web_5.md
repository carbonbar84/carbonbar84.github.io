---
layout: index

title: Servicios de Red e Internet
tagline: CFGS ASIR
---
### Ejercicio: Puertos de escucha

1) Configura apache2 para no usar virtual hosting, y cambia el puerto de escucha del servidor al 8081. ¿Se puede terner el servidor escuchando por dos puertos el 80 y el 8081?

2) Configura apache2 para que use los sitios virtuales de la tarea anterior, pero modifica la configuración para que www.pagina1.com sea visible por el puerto 80, y www.pagina2.com sea visible desde el puero 8081.

*Nota:* Deja el servidor sólo con el sitio virtual default activado, escuchando por el puerto 80.

[Volver](index)
