---
layout: index

title: Servicios de Red e Internet
tagline: CFGS ASIR
---

### Ejercicio: Mediciones de rendimiento de Apache2 sirviendo páginas estáticas

Vamos a comparar el uso de memoria y el rendimiento de Apache2 usando los módulos de preprocesamiento prefork y worker. Para ello vamos a usar tres pruebas distintas:

        5000 peticiones y 50 concurrentes
        50000 peticiones y 100 concurrentes

Hay que generar gráficas de uso de memoria y rendimiento donde se vea la comparativa entre los dos módulos de multiprocesamiento.

Lo más valorado en la tarea serán las conclusiones a las que llegas.



[Volver](index)
