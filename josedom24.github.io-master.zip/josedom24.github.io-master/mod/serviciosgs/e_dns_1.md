---
layout: index

title: Servicios de Red e Internet
tagline: CFGS ASIR
---
### Ejercicio: Instalación y configuración del servidor DNS de Windows 2008 server en nuestra red local


Vamos a crear un servidor dns primario con windows 2008 server, con las siguientes caracterísitcas:

* Los equipos de nuestra red tienen direccionamiento estático en la red 10.0.0.0/24
* La zona que va a conocer nuestro servidor es iesgn.com.
* El servidor DNS con autoridad es *nombre_del_servidor*.iesgn.com
* Se debe resolver los nombres de todas las máquinas.
* Se supone que hay un servidor web que sirve dos páginas webs: www.iesgn.com  y departamento.iesgn.com
* Hay un servidor de base de datos (que está en otra máquina) que se llama mysql.iesgn.com
* El servidor de correo se llama buzon.iesgn.com y está instalado en otra máquina.Además en ese ordenador, tenemos un servidor de correo saliente (smtp.iesgn.com) y otro pop3 (pop.iesgn.com)

[Volver](index)
