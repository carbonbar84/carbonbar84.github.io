---
layout: index

title: Servicios de Red e Internet
tagline: CFGS ASIR
---
### Ejercicio: Instalación y configuración del servidor dhcp en windows

Después de leer la documentación, realiza lo misma configuración que en la [páctica anterior](e_dhcp_1) usando un servidor con Windows Server 2008.

[Volver](index)
