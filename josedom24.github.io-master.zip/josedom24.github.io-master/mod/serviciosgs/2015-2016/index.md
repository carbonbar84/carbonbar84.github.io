---
layout: index

title: Servicios de Red e Internet (2015-2016)
tagline: CFGS ASIR
---

### Prácticas

#### 1ª Evaluación

* [Servidor DHCP (20 puntos)](dhcp)
* [Servidor Web (25 puntos)](web)
* [Servidor DNS (25 puntos)](dns)
* [Configuración de un servidor Windows Server (20 puntos)](wserver)
* [Configuración de un servidor GNU/Linux (20 puntos)](slinux)


#### 2ª Evaluación

* [Estudio de rendimiento de servidores webs (30 puntos)](rendimiento)
* [Estudio de distintos servidores webs (20 puntos)](webservers)
* [Gestionar un hosting por ftp (15 puntos)](ftp)
* [Implantación de un servidor de hosting (35 puntos)](hosting)
* [Servidor de correos (30 puntos)](correo)
* [Servidor proxy/cache squid  (20 puntos)](squid)
* [Balanceador de carga haproxy (20 puntos)](haproxy)


#### Resultados

* [Resultados](https://docs.google.com/spreadsheets/d/1givlUhCq7JFoGeU6_wqAmxR1rflYt2UtwaKzjEglVfc/pubhtml#)

[Volver](http://josedom24.github.io/mod/)
