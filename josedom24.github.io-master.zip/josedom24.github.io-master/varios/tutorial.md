---
layout: index

title: Tutoriales
tagline: www.josedomingo.org
---

### Cursos

* [Infraestructura virtual](http://jj.github.io/IV/	) en [GitHub](https://github.com/JJ/IV).

### Tutoriales

* [Mastering Markdown](https://guides.github.com/features/mastering-markdown/)
* [git - la guía sencilla](http://rogerdudler.github.io/git-guide/index.es.html)
<hr/>
* Los tutoriales de [DigitalOcean](https://www.digitalocean.com/community/tutorials) son bastante interesantes.
<hr/>
* Hojas de referencias:[Cheat sheet](http://www.cheat-sheets.org/)
<hr/>
* [sysadmincasts.com](https://sysadmincasts.com/): Página con tutoriales sobre administración de sistemas
<hr/>
###Docker

* [Cómo desplegar contenedores en Docker](https://platzi.com/blog/desplegar-contenedores-docker/)
* [Podcast: entndiendo docker relacionado con despliegue de aplicaciones](https://soundcloud.com/programania/programania-podcast-1)