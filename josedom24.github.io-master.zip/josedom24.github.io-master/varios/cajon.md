---
layout: index

title: Página web josedom24 @pledin_jd
tagline: www.josedomingo.org
---

## Cajón desastre

De todo un poco...

#### Kodi

Kodi (antes conocido como "Xbox Media Center" o XBMC) es un centro multimedia de entretenimiento multiplataforma bajo la licencia GNU/GPL.

* [Kodi](http://kodi.tv/)
* En las rasperry pi va mejor una adaptación: [OpenElec](http://openelec.tv/)
* [www.pluginsxbmc.com](http://www.pluginsxbmc.com/)
* [blog.tvalacarta.info](http://blog.tvalacarta.info/)
* [superrepo.org](https://superrepo.org/)

<hr/>
#### slimbook

Portátiles compatibles con Linux: [https://slimbook.es](https://slimbook.es)