---
layout: index

title: Página web josedom24 @pledin_jd
tagline: www.josedomingo.org
---

## Herramientas web

* [reveal.js: The HTML Presentation Framework](http://lab.hakim.se/reveal-js/#/)

## Aplicaciones web

* [Paperwork, un Evernote propio y open source](http://paperwork.rocks/)
* [Let's chat](http://sdelements.github.io/lets-chat/)

## Frameworks web

* [Pure CSS](http://purecss.io/)
* [Bootstrap](http://getbootstrap.com/)