---
layout: index

title: Enlaces
tagline: www.josedomingo.org
---

* [Programania](www.programania.ne): sobre desarrollo web y despliegue de aplicaciones, me han interesado las entradas sobre [integración continua](http://www.programania.net/?s=jenkins&submit=Buscar) y sobre [tomcat](http://www.programania.net/?s=tomcat&submit=Buscar)
* [Debian Wiki de flash](https://wiki.debian.org/es/FlashPlayer): Nunca me acuedo como actualiza el plugin de flash.